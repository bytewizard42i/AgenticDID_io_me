# Compact Contracts Support

If you're looking for support for this library, check out:

* Developer Documentation &mdash; [Compact Contracts API Documentation](https://docs.openzeppelin.com/contracts-compact/)
* Github Discussion Board &mdash; [Github Discussions](https://github.com/OpenZeppelin/midnight-contracts/discussions)
* Midnight Forum &mdash; [Midnight Forum Technical Questions](https://forum.midnight.network/t/about-the-technical-questions-category/11)

On the Midnight Forum, there are a bunch of helpful community members that should be willing to point you in the right direction.