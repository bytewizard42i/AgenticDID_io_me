// SPDX-License-Identifier: MIT
// OpenZeppelin Compact Contracts v0.0.1-alpha.0 (token/witnesses/MultiToken.ts)

// This is how we type an empty object.
export type MultiTokenPrivateState = Record<string, never>;
export const MultiTokenWitnesses = {};
