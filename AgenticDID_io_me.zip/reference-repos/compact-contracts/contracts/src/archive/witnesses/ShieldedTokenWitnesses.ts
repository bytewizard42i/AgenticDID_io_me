// SPDX-License-Identifier: MIT
// OpenZeppelin Compact Contracts v0.0.1-alpha.0 (archive/witnesses/ShieldedTokenWitnesses.ts)

// This is how we type an empty object.
export type ShieldedTokenPrivateState = Record<string, never>;
export const ShieldedTokenWitnesses = {};
