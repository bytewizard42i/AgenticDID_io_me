# Reference Repositories

This folder contains example Compact/Midnight contracts used as reference during development.  
**These are NOT part of the AgenticDID project** - they are external examples for learning and pattern-matching.

---

## 📦 Included Repos

### 1. **example-counter** (Official Midnight Network)
**Source**: https://github.com/midnightntwrk/example-counter  
**Purpose**: Official Midnight Network counter example

**What's inside:**
- `/contract/src/counter.compact` - Simple counter contract in Compact 0.15
- Deployment scripts and CLI tools
- Complete template for Midnight dApps

**Use for:**
- ✅ Correct Compact 0.15 syntax patterns
- ✅ Deployment script structure
- ✅ CLI integration patterns
- ✅ TypeScript integration examples

---

### 2. **compact-contracts** (OpenZeppelin)
**Source**: https://github.com/OpenZeppelin/compact-contracts  
**Purpose**: Production-grade security patterns for Compact

**What's inside:**
- `/contracts/src/access/` - AccessControl, Ownable patterns
- `/contracts/src/token/` - FungibleToken, NFT, MultiToken standards
- `/contracts/src/security/` - Pausable, Initializable patterns
- `/contracts/src/utils/` - Helper utilities

**Use for:**
- ✅ Security best practices
- ✅ Access control patterns
- ✅ Token standards (if needed)
- ✅ Production-ready code structure

---

## 🎯 How to Use

**For CodeMaps:**
- Reference these repos when analyzing our `/contracts/` folder
- Compare our syntax to their working examples
- Learn from official patterns

**For Development:**
- Copy patterns (not code) from these examples
- Verify our syntax matches working examples
- Use as compilation test reference

**For Cascade/AI:**
- Provides additional context for fixing our contracts
- Helps understand Compact 0.15 best practices
- Reference for deployment scripts

---

## ⚠️ Important Notes

1. **These are external repos** - not part of our codebase
2. **Added to .gitignore** - won't be committed to our repo
3. **Read-only reference** - don't modify these
4. **Check for updates** - these may evolve over time

---

## 🔄 Updating Reference Repos

```bash
# To update to latest versions:
cd reference-repos/example-counter && git pull origin main
cd ../compact-contracts && git pull origin main
```

---

*Cloned: October 24, 2025*  
*For: AgenticDID.io Midnight Integration*
