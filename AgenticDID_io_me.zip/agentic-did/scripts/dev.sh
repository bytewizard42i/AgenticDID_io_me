#!/bin/bash
# Development script - runs both web and API in parallel

set -e

echo "🚀 Starting AgenticDID.io development servers..."
yarn dev
