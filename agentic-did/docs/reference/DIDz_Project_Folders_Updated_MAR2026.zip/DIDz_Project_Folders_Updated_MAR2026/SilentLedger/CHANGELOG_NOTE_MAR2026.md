# SilentLedger — Changelog Note (March 3, 2026)

- Monolith meta-repo renamed to **DIDzMonolith**.
- Suite-wide Compact contracts audited and rewritten to compile cleanly on **compactc v0.29.0**, totaling **84 circuits** across 5 repos.

(If this project was not in the Compact rewrite set, the note is still relevant as suite context.)
