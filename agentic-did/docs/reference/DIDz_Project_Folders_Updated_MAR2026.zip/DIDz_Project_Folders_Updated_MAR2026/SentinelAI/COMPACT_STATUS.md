# SentinelAI — Compact Status

This repo **contains Compact contracts** and was part of the March 3, 2026 rewrite to Compact v0.29.0.

## Scorecard (from rewrite session)
- **TreasuryOrchestrator.compact** — 7 circuits — Loops → per-action processing
- **RiskProfiler.compact** — 5 circuits — Quiz scoring moved off-chain
- **TreasuryWatchdog.compact** — 7 circuits — Bitwise ops removed, anomaly scoring redesigned
- **MarketGuardian.compact** — 8 circuits — Signed ints → offset encoding, loops → explicit checks

## Compact v0.29.0 idioms (do not regress)

- Use `Boolean` (not `Bool`)
- Use `const` (no `var`)
- No mutation of struct fields — construct a new struct instead
- No iteration/loops in Compact — do iteration off-chain (TypeScript) and pass results into circuits
- Prefer `Map<Bytes<32>, T>` patterns for “list-like” storage
- Use `Bytes<32>` (no `Address` type)
- No signed integers — use offset encoding with `Uint<>`
- Use `assert(cond, "message")`
- Use `ownPublicKey()` (renamed)
- Use `persistentHash<T>(T { ... })` for deterministic IDs and composite keys
- `.member()` / `.lookup()` / `.insert()` for `Map` operations
- No bitwise ops; no division — redesign logic
- No cross-contract imports — keep contracts self-contained


## Build reference
- `compact compile src/contracts/<contract>.compact src/managed/<contract>`

## Proof server
- `docker run -p 6300:6300 midnightntwrk/proof-server:7.0.0`
