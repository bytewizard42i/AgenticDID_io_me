# AutoDiscovery — Project Brief

## What it is
Legal discovery protocol

## GitHub repo
- SpyCrypto/AutoDiscovery

## Suite-wide Compact rewrite status (March 3, 2026)

- All Compact smart contracts across the DIDz ecosystem were audited and rewritten to compile cleanly with **Compact compiler v0.29.0** (language version >= 0.20).
- **Result:** 11 contracts across 5 repos, totaling **84 ZK circuits**, all compiling clean.

### Current compiler reference
- Compiler: `compactc` v0.29.0 (language version 0.21.0)
- Pragma: `pragma language_version >= 0.16;` (forward-compatible; works with 0.20+)
- Compile command: `compact compile src/contracts/foo.compact src/managed/foo`
- Proof Server: v7.0.0 (`docker run -p 6300:6300 midnightntwrk/proof-server:7.0.0`)
- Network: Preprod (tDUST tokens)


## Notes for future conversations
- This folder is meant to keep a stable, human-readable snapshot of what AutoDiscovery is and how it fits into the DIDz suite.
- Update this file whenever you change scope, rename components, or ship major milestones.
