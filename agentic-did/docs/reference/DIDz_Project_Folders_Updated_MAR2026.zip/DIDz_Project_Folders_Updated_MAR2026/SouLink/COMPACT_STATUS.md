# SouLink — Compact Status

This repo is **not listed** in the Compact rewrite scorecard (March 3, 2026).

If Compact contracts are added here later:
- Target `compactc` v0.29.0 (language >= 0.20)
- Use the suite idioms and compiler reference in the monolith briefing.
