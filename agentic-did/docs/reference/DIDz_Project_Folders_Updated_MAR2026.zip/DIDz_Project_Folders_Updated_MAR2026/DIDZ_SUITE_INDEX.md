# DIDz Suite — Project Folder Index (Updated March 3, 2026)

These folders mirror the DIDzMonolith submodules and include per-project briefs and Compact status notes.

## Projects

1. **DIDz-io** — FOUNDATION — DID platform for users, orgs, objects (repo: `didz-dapp-system`)
2. **KYCz** — No-frills KYC verification (informs DIDz design) (repo: `KYCz_us_app`)
3. **AgenticDID** — AI agent identity — separate from DIDz (agents only) (repo: `AgenticDID_io_me`)
4. **ProMingle** — Decentralized professional networking (repo: `ProMingle_net`)
5. **SouLink** — Leverages DIDz for its protocol (repo: `SouLink_me`)
6. **PopCork** — Semi-decentralized social media (repo: `PopCork`)
7. **HuddleBridge** — Decentralized xSpaces/Zoom/Meet (plug-in architecture) (repo: `huddlebridge_app_me_us`)
8. **DownMan** — Crypto estate planning via Shamir secret shares (repo: `DownMan`)
9. **safeHealthData** — Health data privacy (repo: `safeHealthData_me`)
10. **EnterpriseZK** — Portfolio/umbrella brand (repo: `EnterpriseZK_com`)
11. **AutoDiscovery** — Legal discovery protocol (repo: `SpyCrypto/AutoDiscovery`)
12. **SentinelAI** — Treasury safety & market monitoring (repo: `SentinelAi_services`)
13. **SentinelDID** — DID issuance/verification PoC (repo: `SentinelDID-poc`)
14. **SilentLedger** — Privacy-preserving asset verification & orderbooks (repo: `SilentLedger`)
15. **MidnightVitals** — Real-time debugging/diagnostics for all projects (repo: `MidnightVitals`)
16. **EncryptVault** — Encryption utilities (repo: `EncryptVault`)
17. **GeoZ** — Geolocation oracle for Midnight (repo: `GeoZ_us_app_Midnight-Oracle`)

## Excluded/private
- PixyPi, preProd-Wallets, create-midnight-app fork, Idris MCP fork.

## Suite-wide Compact rewrite status (March 3, 2026)

- All Compact smart contracts across the DIDz ecosystem were audited and rewritten to compile cleanly with **Compact compiler v0.29.0** (language version >= 0.20).
- **Result:** 11 contracts across 5 repos, totaling **84 ZK circuits**, all compiling clean.

### Current compiler reference
- Compiler: `compactc` v0.29.0 (language version 0.21.0)
- Pragma: `pragma language_version >= 0.16;` (forward-compatible; works with 0.20+)
- Compile command: `compact compile src/contracts/foo.compact src/managed/foo`
- Proof Server: v7.0.0 (`docker run -p 6300:6300 midnightntwrk/proof-server:7.0.0`)
- Network: Preprod (tDUST tokens)
